package com.src;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dao.CarDao;
import com.model.Car;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		
		CarDao cdao=(CarDao) context.getBean("cardao1");
		
		int status=cdao.saveCar(new Car(20,"swift",700000));
				
		if(status>0)
		{
			System.out.println("values got inserted");
		}
		else
		{
			System.out.println("unable to insert values");
		}

	 status=cdao.deleteCar(new Car(25,"",700000));
		
		if(status>0)
		{
			System.out.println("values got delete");
		}
		else
		{
			System.out.println("unable to delete");
	
		}
		Boolean status1=cdao.saveCarbyPs(new Car(2,"audi",30000000));
		
		if(!status1)
			System.out.println("values inserted by prepared statement");
		else
			System.out.println("unsuccessfull insertion by preparedstatement");
		
		
Boolean status2=((CarDao) cdao).UpdateCar(new Car(2,"rolls royce",0));
		if(!status2) {
			System.out.println("updated");}
		else {
			System.out.println("not updated");
		}
		List<Car> l=cdao.getCars();
		 for(Car c:l)
		 {
			 System.out.println(c);
		 }
		 
	}

}
