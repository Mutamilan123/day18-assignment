package com.model;

public class Car {
private int carid;
private String carname;
private double cprice;

public Car() {
	
}
public Car(int carid, String carname, double cprice) {
	//super();
	this.carid = carid;
	this.carname = carname;
	this.cprice = cprice;
}
public int getCarid() {
	return carid;
}
public void setCarid(int carid) {
	this.carid = carid;
}
public String getCarname() {
	return carname;
}
public void setCarname(String carname) {
	this.carname = carname;
}
public double getCprice() {
	return cprice;
}
public void setCprice(double cprice) {
	this.cprice = cprice;
}
@Override
public String toString() {
	return "Car [carid=" + carid + ", carname=" + carname + ", cprice=" + cprice + "]";
}

}
