package com.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.model.Car;

public class CarDao {
	private JdbcTemplate jdbctemp;

	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}
	public int saveCar(Car c)
	{
		String sql="insert into car values("+c.getCarid()+ ",'" +c.getCarname()+ "'," +c.getCprice()+")";
				
		return jdbctemp.update(sql); 
	}
	public int deleteCar(Car c)
	{
		String sql="delete from car where carid="+c.getCarid();					
		return jdbctemp.update(sql); 
	}
	public Boolean saveCarbyPs(Car c)
	{

		String sql="insert into car values(?,?,?)";
		return jdbctemp.execute(sql,new PreparedStatementCallback<Boolean>()
				{

					public Boolean doInPreparedStatement(PreparedStatement ps)
							throws SQLException, DataAccessException {
						// TODO Auto-generated method stub
					
			
			
			ps.setInt(1,c.getCarid());
			ps.setString(2,c.getCarname());
			ps.setDouble(3, c.getCprice());
			return ps.execute();
			
			
					}		
				});
				
}

public Boolean UpdateCar(Car c)
{
	String sql = "UPDATE car "
            + "SET carid = ? "
            + "WHERE carname = ?";
	return jdbctemp.execute(sql,new PreparedStatementCallback<Boolean>()
			{

				public Boolean doInPreparedStatement(PreparedStatement ps)
						throws SQLException, DataAccessException {
					// TODO Auto-generated method stub
				
		
		
		ps.setInt(1,c.getCarid());
		ps.setString(2,c.getCarname());
	
		return ps.execute();
		
		
				}		
			});
			
}

	public List<Car> getCars()
	{
		
		String sql="select * from car;";
		ResultSetExtractor rse=new ResultSetExtractor() {

			@Override
			public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
				List<Car> list=new ArrayList<>();
				while(rs.next())
				{
					list.add(new Car(rs.getInt(1), rs.getString(2),rs.getDouble(3)));
				}
				return list;
			}
			
		};
		return (List<Car>) jdbctemp.query(sql, rse);
		
	}
}
